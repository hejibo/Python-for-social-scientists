# sentiment-analysis
Using tensorflow to do sentiment analysis based on the IMDB
