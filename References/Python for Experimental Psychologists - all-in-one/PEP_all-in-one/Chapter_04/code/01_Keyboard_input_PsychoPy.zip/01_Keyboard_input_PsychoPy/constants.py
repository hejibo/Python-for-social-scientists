# display resolution (should match monitor settings!)
DISPSIZE = (1920, 1080)
# foreground and background
FGC = (-1, -1, -1)
BGC = (1, 1, 1)