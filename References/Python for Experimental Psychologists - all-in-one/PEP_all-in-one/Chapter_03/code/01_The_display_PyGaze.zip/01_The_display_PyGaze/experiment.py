from pygaze.display import Display
import pygaze.libtime as timer

# Initialise a new Display instance.
disp = Display()

# Update the display (this makes the grey background visible).
disp.show()

# Pause for two seconds.
timer.pause(2000)

# Close the Display again.
disp.close()