Stroop - gaze test with Tobii
-----------------------------
Borrowed from the Stroop eye tracking demo that comes with PsychoPy.  This has been fixed up to work knowingly with our Tobii T60XL portable.

The calibration part has been fixed, which had an issue due to the full screen window of experiments.

The configuration YAML file has been adjusted to the correct sample rate, and also set to automate the calibration steps.

This will demonstrate gaze tracking also.