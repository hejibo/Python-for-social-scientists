# the Display size should match the monitor resolution
DISPSIZE = (1920, 1080)
# foreground and background
FGC = (-1, -1, -1)
BGC = (0, 0, 0)

# potential cue locations
CUELOCS = ['right', 'left']
# potential target locations
TARLOCS = ['right', 'left']
# potential SOAs
SOAS = [0.093, 0.893]
# potential targets
TARGETS = ['E', 'F']

# fixation time at the start of a trial
FIXTIME = 1.493
# duration of the cue Screen
CUETIME = 0.043
# duration of the feedback Screen
FEEDBACKTIME = 0.993

# ask for the log file's name
LOGFILENAME = raw_input('Participant name: ')
LOGFILE = LOGFILENAME

# number of times to repeat all unique trials
TRIALREPEATS = 20

# define the boxes' width and height (same number: they're square!)
BOXSIZE = 200
# define the boxes' centre coordinates
BOXCORS = {}
BOXCORS['left'] = (int(DISPSIZE[0]*-0.25), 0)
BOXCORS['right'] = (int(DISPSIZE[0]*0.25), 0)