# Window resolution.
DISPSIZE = (1920, 1080)

# Default foreground and background colour.
FGC = (-1, -1, -1)
BGC = (0, 0, 0)