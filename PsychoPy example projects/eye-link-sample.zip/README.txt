EyeLink Test Script
-------------------
Should work on PsychoPy V1.82.01 and above.

A demo script which was initially set up between SR Research and Dr Joe Brooks.  Extended slightly by Frank Gasking to provide a demonstration script for people to use.

This script links up to the EyeLink which will run at the very start before doing the experiment.  When you exit the EyeLink setup, it will begin the experiment and saving to an EDF file.

Recording is started in the "start_recording" code block.  It takes 10-30 milliseconds for the recording to start from that point.

Within your experiment trials, you can make use of a codeblock to send messages during recording, to set markers.  This is done via the "eyelink_msg" codeblock under "trial" as an example.

When the experiment finishes, it will shut down the eyelink and save the file at the end.

SEE /docs for PYLINK API AND COMMANDS THAT CAN BE USED