# display resolution (should match monitor settings!)
DISPSIZE = (1920, 1080)
# display type (either 'pygame' or 'psychopy')
DISPTYPE = 'psychopy'
# foreground and background
FGC = (0, 0, 0)
BGC = (128, 128, 128)