Copy the data from the `experiment/data` directory to this directory.
