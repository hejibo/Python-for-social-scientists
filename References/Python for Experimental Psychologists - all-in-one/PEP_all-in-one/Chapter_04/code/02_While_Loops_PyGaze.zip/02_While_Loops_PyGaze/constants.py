# the display size should match the monitor's resolution
DISPSIZE = (1920, 1080)
# the display type can be 'pygame' or 'psychopy'
DISPTYPE = 'pygame'
# the foreground and background colour are (red, green, blue)
# the values are 0 (no colour) to 255 (full colour)
FGC = (255, 255, 255)
BGC = (0, 0, 0)