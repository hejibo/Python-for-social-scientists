PyTribe
=======

Python wrapper for the EyeTribe SDK by Edwin Dalmaijer. Version 3, 11-08-2014.


example
-------

Please refer to the *example* directory for an example experiment and analysis script.
