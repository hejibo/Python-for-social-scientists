# the Display size should match the monitor resolution
DISPSIZE = (1920, 1080)
# the Display type should be set to 'psychopy' for this one
DISPTYPE = 'psychopy'
# foreground and background
FGC = (0, 0, 0)
BGC = (128,128,128)

# potential cue locations
CUELOCS = ['right', 'left']
# potential target locations
TARLOCS = ['right', 'left']
# potential SOAs
SOAS = [93, 893]
# potential targets
TARGETS = ['E', 'F']

# fixation time at the start of a trial
FIXTIME = 1493
# duration of the cue Screen
CUETIME = 43
# duration of the feedback Screen
FEEDBACKTIME = 993

# ask for the log file's name
LOGFILENAME = raw_input('Participant name: ')
LOGFILE = LOGFILENAME

# number of times to repeat all unique trials
TRIALREPEATS = 20

# define the boxes' width and height (same number: they're square!)
BOXSIZE = 200
# define the boxes' centre coordinates
BOXCORS = {}
BOXCORS['left'] = (int(DISPSIZE[0]*0.25 - BOXSIZE*0.5), \
    int(DISPSIZE[1]*0.5 - BOXSIZE*0.5))
BOXCORS['right'] = (int(DISPSIZE[0]*0.75 - BOXSIZE*0.5), \
    int(DISPSIZE[1]*0.5 - BOXSIZE*0.5))