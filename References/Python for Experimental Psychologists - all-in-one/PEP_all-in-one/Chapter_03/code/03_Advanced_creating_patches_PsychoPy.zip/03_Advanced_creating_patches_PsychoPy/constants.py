# Set the Window size (this should match the resolution)
DISPSIZE = (1920, 1080)