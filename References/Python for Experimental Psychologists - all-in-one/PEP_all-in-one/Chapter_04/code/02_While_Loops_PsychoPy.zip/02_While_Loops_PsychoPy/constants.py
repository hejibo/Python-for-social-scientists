# the display size should match the monitor's resolution
DISPSIZE = (1920, 1080)
# the foreground and background colour are (red, green, blue)
# the values are -1 (no colour) to 1 (full colour)
FGC = (1, 1, 1)
BGC = (-1, -1, -1)