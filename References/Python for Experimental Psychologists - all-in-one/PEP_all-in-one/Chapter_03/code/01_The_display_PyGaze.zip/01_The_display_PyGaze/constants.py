# Display settings (type and resolution).
DISPTYPE = 'pygame'
DISPSIZE = (1920, 1080)

# Default foreground and background colour.
FGC = (0, 0, 0)
BGC = (128, 128, 128)