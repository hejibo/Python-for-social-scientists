# constants for PyGaze_trackertest.py

DISPTYPE = 'pygame'
DISPSIZE = 1920, 1080

DUMMYMODE = True
TRACKERTYPE = 'smi'