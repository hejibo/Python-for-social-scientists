# Set the Display size (this should match the resolution).
DISPSIZE = (1920, 1080)
# Set the Display type.
DISPTYPE = 'psychopy'