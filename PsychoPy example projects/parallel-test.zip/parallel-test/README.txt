Parallel Test Script
--------------------
A very simple script to show two ways to fire to a Parallel cable in PsychoPy.  First by Parallel component and secondly by code.

Code version is useful for when you have complex conditions to determine what code should be fired, which is tricky to achieve using just the Parallel component.  If you are just firing a basic single value trigger at a particular point, we recommend the Parallel component.

Running this script without a validly set up parallel port will result in an error.  You will need to also correctly set the Port address.  If you continue to get errors, it could be due to the drivers for your port being incorrect - please contact Technical Support if you get any problems.

IMPORTANT NOTES

1) When using the Code version of the parallel firing method, it is VERY important to CLEAR the signal to 0 afterwards.   Not doing this will result in values overlapping and causing strange results.

2) Ensure you leave a suitable gap between signal firing, as otherwise - overlapped values can occur again.   This is particularly important in TMS and EEG based trigger firing.

3) When using the code edition - you generally fire the trigger at the Begin Routine tab.   If you set the clear signal within the "End Routine" tab, then the signal fired will be for the duration of the routine.  If you need it for less time, then you would need to add a timer and check on "Each Frame" tab if it is time to clear the signal yet.